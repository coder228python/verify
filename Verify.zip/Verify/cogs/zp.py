# cogs/zp.py (альтернативный вариант)
from pymongo import MongoClient
import datetime
from disnake.ext import commands

# Подключение к MongoDB
mongodb_client = MongoClient("mongodb+srv://tokae2:zpNCOrZTPWmt@cluster0.ayrh5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = mongodb_client["ave"]
coll_salary = db["zp"]  # Коллекция для зарплат

def calculate_and_save_salary(user_id, stats_data):
    """
    Расчет зарплаты и сохранение в отдельную коллекцию
    За каждую верификацию: 100 монет
    За каждый варн: -100 монет (штраф)
    """
    # Расчет зарплаты за верификации
    salary = stats_data.get('verify', 0) * 100
    
    # Штраф за варны
    warns_count = stats_data.get('warns', 0)
    salary -= warns_count * 100
    
    # Зарплата не может быть отрицательной
    salary = max(0, salary)
    
    # Данные для сохранения
    salary_data = {
        "user_id": user_id,
        "salary": salary,
        "verify_count": stats_data.get('verify', 0),
        "warns_count": warns_count,
        "online_seconds": stats_data.get('online', 0),
        "calculated_at": datetime.datetime.now(),
        "last_updated": datetime.datetime.now()
    }
    
    # Сохранение в коллекцию зарплат
    coll_salary.update_one(
        {"user_id": user_id},
        {"$set": salary_data},
        upsert=True
    )
    
    return salary

def get_salary(user_id):
    """
    Получение зарплаты из коллекции
    """
    salary_data = coll_salary.find_one({"user_id": user_id})
    if salary_data:
        return salary_data.get('salary', 0)
    return 0

class Zp(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

def setup(bot):
    bot.add_cog(Zp(bot))