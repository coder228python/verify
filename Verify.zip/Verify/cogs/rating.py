# cogs/rating.py
from pymongo import MongoClient
from disnake.ext import commands

# Подключение к MongoDB
mongodb_client = MongoClient("mongodb+srv://tokae2:zpNCOrZTPWmt@cluster0.ayrh5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = mongodb_client["ave"]
coll_stats = db["stats"]  # Коллекция со статистикой

class Rating(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def calculate_rating(self, user_id):
        """
        Расчет рейтинга пользователя на основе верификаций
        Возвращает позицию в рейтинге и общее количество участников
        """
        # Получаем всех пользователей, отсортированных по верификациям (по убыванию)
        all_users = list(coll_stats.find().sort("verify", -1))
        
        # Находим позицию пользователя
        user_position = None
        for i, user in enumerate(all_users):
            if user['id'] == user_id:
                user_position = i + 1  # Позиция начинается с 1
                break
        
        total_users = len(all_users)
        
        return user_position, total_users

    def get_top_users(self, limit=3):
        """
        Получение топ-N пользователей по верификациям
        """
        return list(coll_stats.find().sort("verify", -1).limit(limit))

    def get_user_verify_count(self, user_id):
        """
        Получение количества верификаций пользователя
        """
        user_stats = coll_stats.find_one({"id": user_id})
        return user_stats.get('verify', 0) if user_stats else 0

# Глобальные функции для импорта
def calculate_rating(user_id):
    """
    Глобальная функция расчета рейтинга
    """
    all_users = list(coll_stats.find().sort("verify", -1))
    user_position = None
    for i, user in enumerate(all_users):
        if user['id'] == user_id:
            user_position = i + 1
            break
    total_users = len(all_users)
    return user_position, total_users

def get_top_users(limit=3):
    """
    Глобальная функция получения топ пользователей
    """
    return list(coll_stats.find().sort("verify", -1).limit(limit))

def get_user_verify_count(user_id):
    """
    Глобальная функция получения количества верификаций
    """
    user_stats = coll_stats.find_one({"id": user_id})
    return user_stats.get('verify', 0) if user_stats else 0

def setup(bot):
    bot.add_cog(Rating(bot))