import disnake
from disnake.ext import commands
from disnake.ui import View, Button, Modal, TextInput, Select
import os
import time
import pymongo
import datetime
from config import *


client = pymongo.MongoClient("")
coll = client.ave.neverify
coll2 = client.ave.pingtime
coll3 = client.ave.stats
coll4 = client.ave.fullstatsverifyday


coll_role_assign = client.ave.role_assignments

class OnlineModal(Modal):
    def __init__(self, user_id):
        self.user_id = user_id
        components = [
            TextInput(
                label="Количество часов",
                placeholder="Введите количество часов",
                custom_id="hours",
                style=disnake.TextInputStyle.short,
                max_length=3,
                required=True
            )
        ]
        super().__init__(title="Выдать онлайн", components=components, timeout=60)

    async def callback(self, interaction: disnake.Interaction):
        try:
            hours = int(interaction.text_values["hours"])
            seconds = hours * 3600
            
            find = coll3.find_one({"id": self.user_id})
            if find:
                coll3.update_one({"id": self.user_id}, {"$inc": {"online": seconds}})
                await interaction.response.send_message(
                    f"✅ Выдано {hours} часов онлайна пользователю <@{self.user_id}>",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message("❌ Пользователь не найден в базе", ephemeral=True)
                
        except ValueError:
            await interaction.response.send_message("❌ Введите корректное число часов", ephemeral=True)

class WarnModal(Modal):
    def __init__(self, user_id):
        self.user_id = user_id
        components = [
            TextInput(
                label="Причина варна",
                placeholder="Укажите причину выдачи варна",
                custom_id="reason",
                style=disnake.TextInputStyle.paragraph,
                max_length=500,
                required=True
            )
        ]
        super().__init__(title="Выдать варн", components=components, timeout=60)

    async def callback(self, interaction: disnake.Interaction):
        reason = interaction.text_values["reason"]
        
        find = coll3.find_one({"id": self.user_id})
        if find:
            current_warns = find.get('warns', 0)
            new_warns = current_warns + 1
            
            coll3.update_one({"id": self.user_id}, {"$set": {"warns": new_warns}})
            
            await interaction.response.send_message(
                f"⚠️ Выдан варн пользователю <@{self.user_id}>\n"
                f"Теперь у него {new_warns} варнов\n"
                f"Причина: {reason}",
                ephemeral=True
            )
        else:
            await interaction.response.send_message("❌ Пользователь не найден в базе", ephemeral=True)

class RoleSelectView(View):
    def __init__(self, user_id, curator_id):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.curator_id = curator_id
        
        role_options = []
        for role_id in config.get('manageable_roles', []):
            role_options.append(disnake.SelectOption(
                label=f"Роль ID: {role_id}",
                value=str(role_id),
                description=f"ID роли: {role_id}"
            ))
        
        if role_options:
            self.add_item(RoleSelect(role_options, user_id, curator_id))

class RoleSelect(Select):
    def __init__(self, options, user_id, curator_id):
        super().__init__(
            placeholder="Выберите роль для выдачи...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.user_id = user_id
        self.curator_id = curator_id

    async def callback(self, interaction: disnake.Interaction):
        role_id = int(self.values[0])
        
        guild = interaction.guild
        member = guild.get_member(self.user_id)
        role = guild.get_role(role_id)
        
        if not member:
            await interaction.response.send_message("❌ Пользователь не найден на сервере", ephemeral=True)
            return
            
        if not role:
            await interaction.response.send_message("❌ Роль не найдена на сервере", ephemeral=True)
            return
            
        if role in member.roles:
            await interaction.response.send_message(f"❌ У пользователя уже есть роль {role.mention}", ephemeral=True)
            return
            
        try:
            await member.add_roles(role, reason=f"Роль выдана куратором {interaction.user}")
            
            coll_role_assign.update_one(
                {"user_id": self.user_id, "role_id": role_id},
                {"$set": {
                    "assigned_by": self.curator_id,
                    "assigned_at": time.time(),
                    "guild_id": guild.id
                }},
                upsert=True
            )
            
            await interaction.response.send_message(
                f"✅ Роль {role.mention} (ID: {role_id}) успешно выдана пользователю <@{self.user_id}>\n"
                f"📝 Выдал: {interaction.user.mention}",
                ephemeral=True
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Ошибка при выдаче роли: {str(e)}", ephemeral=True)

class RemoveRoleSelectView(View):
    def __init__(self, user_id, curator_id):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.curator_id = curator_id
        
        role_options = []
        for role_id in config.get('manageable_roles', []):
            role_options.append(disnake.SelectOption(
                label=f"Роль ID: {role_id}",
                value=str(role_id),
                description=f"ID роли: {role_id}"
            ))
        
        if role_options:
            self.add_item(RemoveRoleSelect(role_options, user_id, curator_id))

class RemoveRoleSelect(Select):
    def __init__(self, options, user_id, curator_id):
        super().__init__(
            placeholder="Выберите роль для снятия...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.user_id = user_id
        self.curator_id = curator_id

    async def callback(self, interaction: disnake.Interaction):
        role_id = int(self.values[0])
        
        guild = interaction.guild
        member = guild.get_member(self.user_id)
        role = guild.get_role(role_id)
        
        if not member:
            await interaction.response.send_message("❌ Пользователь не найден на сервере", ephemeral=True)
            return
            
        if not role:
            await interaction.response.send_message("❌ Роль не найдена на сервере", ephemeral=True)
            return
            
        if role not in member.roles:
            await interaction.response.send_message(f"❌ У пользователя нет роли {role.mention}", ephemeral=True)
            return
            
        try:
            await member.remove_roles(role, reason=f"Роль снята куратором {interaction.user}")
            
            coll_role_assign.delete_one({"user_id": self.user_id, "role_id": role_id})
            
            await interaction.response.send_message(
                f"✅ Роль {role.mention} (ID: {role_id}) успешно снята с пользователя <@{self.user_id}>\n"
                f"📝 Снял: {interaction.user.mention}",
                ephemeral=True
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Ошибка при снятии роли: {str(e)}", ephemeral=True)

class CuratorPanel(View):
    def __init__(self, user_id, curator_id):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.curator_id = curator_id

    @disnake.ui.button(label="Выдать зарплату", style=disnake.ButtonStyle.green, disabled=True)
    async def salary_button(self, button: Button, interaction: disnake.Interaction):
        pass

    @disnake.ui.button(label="Выдать онлайн", style=disnake.ButtonStyle.blurple)
    async def online_button(self, button: Button, interaction: disnake.Interaction):
        await interaction.response.send_modal(OnlineModal(self.user_id))

    @disnake.ui.button(label="Выдать варн", style=disnake.ButtonStyle.red)
    async def warn_button(self, button: Button, interaction: disnake.Interaction):
        await interaction.response.send_modal(WarnModal(self.user_id))

    @disnake.ui.button(label="Сбросить статистику", style=disnake.ButtonStyle.grey)
    async def reset_button(self, button: Button, interaction: disnake.Interaction):
        coll3.update_one({"id": self.user_id}, {"$set": {
            "online": 0,
            "verify": 0,
            "unverify": 0,
            "warns": 0
        }})
        
        await interaction.response.send_message(
            f"✅ Статистика пользователя <@{self.user_id}> сброшена\n"
            f"✅ Варны обнулены",
            ephemeral=True
        )

    @disnake.ui.button(label="Выдать роль", style=disnake.ButtonStyle.success)
    async def assign_role_button(self, button: Button, interaction: disnake.Interaction):
        view = RoleSelectView(self.user_id, self.curator_id)
        await interaction.response.send_message("Выберите роль для выдачи:", view=view, ephemeral=True)

    @disnake.ui.button(label="Снять роль", style=disnake.ButtonStyle.danger)
    async def remove_role_button(self, button: Button, interaction: disnake.Interaction):
        view = RemoveRoleSelectView(self.user_id, self.curator_id)
        await interaction.response.send_message("Выберите роль для снятия:", view=view, ephemeral=True)

class Prosmotr(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command()
    @commands.has_any_role(*config.get('curator_roles', [1411241141982072832, 987654321]))
    async def curator(self, interaction):
        pass

    @curator.sub_command(name="panel", description="Панель управления пользователем")
    async def curator_panel(self, interaction, пользователь: disnake.User):
        find = coll3.find_one({"id": пользователь.id})
        
        embed = disnake.Embed(
            title=f"Панель управления пользователем - {пользователь}",
            description=f"Выберите действие...",
            color=0x2f3136
        )
        
        embed.set_thumbnail(url=пользователь.display_avatar.url)
        
        embed.add_field(
            name="👤 Информация",
            value=f"**ID:** {пользователь.id}\n"
                  f"**Создан:** {disnake.utils.format_dt(пользователь.created_at, style='D')}\n"
                  f"**Присоединился:** {disnake.utils.format_dt(пользователь.joined_at, style='D') if пользователь.joined_at else 'Неизвестно'}",
            inline=False
        )
        
        if find:
            online_seconds = find.get('online', 0)
            hours = online_seconds // 3600
            minutes = (online_seconds % 3600) // 60
            time_str = f"{hours} ч. {minutes} мин"
            
            norm_seconds = 5400
            percentage = min(100, (online_seconds / norm_seconds) * 100)
            
            embed.add_field(
                name="📊 Статистика",
                value=f"**Онлайн:** {time_str}\n"
                      f"**Процент от нормы:** {percentage:.1f}%\n"
                      f"**Верификации:** {find.get('verify', 0)}\n"
                      f"**Недопуски:** {find.get('unverify', 0)}\n"
                      f"**Варны:** {find.get('warns', 0)}",
                inline=False
            )
        else:
            embed.add_field(
                name="📊 Статистика",
                value="❌ Пользователь не найден в базе статистики",
                inline=False
            )
        
        assigned_roles = coll_role_assign.find({"user_id": пользователь.id})
        role_info = ""
        for assignment in assigned_roles:
            role_id = assignment.get('role_id')
            curator_id = assignment.get('assigned_by')
            assigned_at = assignment.get('assigned_at', time.time())
            assigned_time = disnake.utils.format_dt(datetime.datetime.utcfromtimestamp(assigned_at), style='R')  # ← ИСПРАВЛЕНО
            
            role_info += f"• **Роль ID: {role_id}** - выдал <@{curator_id}> ({assigned_time})\n"
        
        if role_info:
            embed.add_field(
                name="🎭 Выданные роли",
                value=role_info,
                inline=False
            )
        
        view = CuratorPanel(пользователь.id, interaction.user.id)
        
        await interaction.response.send_message(embed=embed, view=view)

    @curator.sub_command(name="info", description="Информация о выданных ролях")
    async def curator_info(self, interaction, пользователь: disnake.User):
        assigned_roles = list(coll_role_assign.find({"user_id": пользователь.id}))
        
        if not assigned_roles:
            await interaction.response.send_message(
                f"❌ Информация о выданных ролях для пользователя <@{пользователь.id}> не найдена",
                ephemeral=True
            )
            return
            
        embed = disnake.Embed(
            title=f"Информация о выданных ролях",
            description=f"Пользователь: {пользователь.mention}",
            color=0x2f3136
        )
        embed.set_thumbnail(url=пользователь.display_avatar.url)
        
        for assignment in assigned_roles:
            role_id = assignment.get('role_id')
            curator_id = assignment.get('assigned_by')
            assigned_at = assignment.get('assigned_at', time.time())
            assigned_time = disnake.utils.format_dt(datetime.datetime.utcfromtimestamp(assigned_at), style='F')  # ← ИСПРАВЛЕНО
            
            embed.add_field(
                name=f"🎭 Роль ID: {role_id}",
                value=f"**Выдал:** <@{curator_id}>\n"
                      f"**Время выдачи:** {assigned_time}",
                inline=False
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

def setup(bot):
    bot.add_cog(Prosmotr(bot))