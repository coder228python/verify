config = {
    "token": "",
    "print": "123",
    "man": "",
    "girl": "",
    "otzivi": "",
    "logi": "",
    "unverify": "",
    "nedopusk": "",
    "support": "",
    "guild_id": "",
    "server_name": "VARO WORK",
    "dot": " ",
    'curator_roles': [1411241141982072832, 987654321],
    'manageable_roles': [1367941751959982160, 987654321, 112233445]
}